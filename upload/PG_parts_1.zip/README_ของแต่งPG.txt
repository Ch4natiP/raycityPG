ของแต่งธีม PG ชุดแรก — ใช้ได้กับรถทุกคัน (car/1.common)

วิธีใส่: แตก zip แล้ววางโฟลเดอร์ car ทับโฟลเดอร์ car ในเกม (สำรอง list.xml เดิมของ plate / lamp / wheel ไว้ก่อน)
  car/1.common/plate/  common_plate_pg_raycity.png + _s.dds + icon/common_plate_pg_raycity.png + list.xml
  car/1.common/lamp/   common_lamp_pg_roofsign.png + _s.dds + icon/common_lamp_pg_roofsign.png + list.xml
  car/1.common/wheel/  common_wheel_pg_te37_blue.png + _s.dds + icon/ (ล้อปกติ + _wide) + list.xml

ของใหม่และเลข id — ต้องเพิ่มไอเท็มในฐานข้อมูลของเซิฟด้วยเลขพวกนี้ ไม่งั้นจะไม่มีในร้าน/กระเป๋า:
  ป้ายทะเบียน  1101  pg_raycity
  lamp         467   pg_roofsign        (ทรงป้ายบนหลังคา taxi_round)
  ล้อ          1192  pg_te37_blue       (ทรง rbrc_wolk_te37w)
  ล้อกว้าง     1193  pg_te37_blue_wide  (ทรง rbrc_wolk_te37w_wide)

list.xml ในนี้ = ของเดิมจากไฟล์เกมที่ส่งมา (RB ฉบับแตกไฟล์) + บรรทัดใหม่ต่อท้าย
ถ้าเกมหรือเซิฟมีของแต่งที่เพิ่มหลังจากนั้น อย่าวางทับ list.xml ให้เพิ่มบรรทัดเหล่านี้เองก่อนบรรทัด </partlist>:
  plate/list.xml   <part id="1101" name="pg_raycity" tex="common_plate_pg_raycity"/>
  lamp/list.xml    <part id='467' name='pg_roofsign' mesh='taxi_round' tex='common_lamp_pg_roofsign'/>
  wheel/list.xml   <part id='1192' name='pg_te37_blue' mesh='rbrc_wolk_te37w' tex='common_wheel_pg_te37_blue'/>
                   <part id='1193' name='pg_te37_blue_wide' mesh='rbrc_wolk_te37w_wide' tex='common_wheel_pg_te37_blue'/>
  (list.xml เป็น UTF-16: เปิดด้วย Notepad แล้วบันทึกแบบ Unicode เหมือนเดิม)
ถ้าเซิฟมีโฟลเดอร์ car/1.common ของตัวเอง ใส่ไฟล์ชุดเดียวกันที่เซิฟด้วย
