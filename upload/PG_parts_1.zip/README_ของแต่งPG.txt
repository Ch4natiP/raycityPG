ของแต่งธีม PG — ใช้ได้กับรถทุกคัน (car/1.common)
** ดูไฟล์ PG_import.zip ที่แยกให้แล้วว่า "ไฟล์ไหนเข้า .jmd ไหน" จะง่ายกว่า **

ของและเลข id (ต้องเพิ่มในฐานข้อมูลเซิฟด้วย ไม่งั้นไม่ขึ้นร้าน/กระเป๋า):
  ป้ายทะเบียน 1101 pg_raycity        -> ไฟล์แยก (ใช้ได้แล้ว)
  lamp        467  pg_roofsign       -> ไฟล์แยก (ใช้ได้แล้ว)  ทรง taxi_round
  ล้อ         1192 pg_te37_blue      -> เข้า wheel.jmd         ทรง rbrc_wolk_te37w
  ล้อกว้าง    1193 pg_te37_blue_wide -> เข้า wheel.jmd         ทรง rbrc_wolk_te37w_wide
  ลาย         1001 pg_raycity        -> ภาพเข้า decal4.jmd / บรรทัดเข้า decalinfo list
  ฟิล์ม       743  pg_raycity        -> เข้า glass.jmd

ลาย: มี 2 แบบ decel_pg_raycity (ใช้ alpha) และ decel_pg_raycity_k (พื้นดำแบบลายโลโก้เกม) ลองทีละแบบ
ทุกไฟล์ .jmd ของเซิฟตอนนี้เป็น J2m เปิด JmdStudio เพิ่มไฟล์ได้ — ทดสอบบนก๊อปก่อนลงเซิฟสด
