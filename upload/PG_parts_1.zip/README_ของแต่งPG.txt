ของแต่งธีม PG — ใช้ได้กับรถทุกคัน (car/1.common)

วิธีใส่ (แบบไฟล์แยก): แตก zip แล้ววางโฟลเดอร์ car ทับในเกม สำรอง list.xml เดิมของแต่ละชนิดไว้ก่อน
  car/1.common/plate/      ป้ายทะเบียน
  car/1.common/lamp/       ป้ายบนหลังคา
  car/1.common/wheel/      ล้อ (ปกติ + กว้าง)
  car/1.common/decalinfo/  ลาย (ติดตัวถัง)

** ถ้าเกมอ่านของแต่งจากไฟล์ .jmd (เช่น decalinfo.jmd, glass.jmd) ไม่ใช่โฟลเดอร์ไฟล์แยก:
   ให้เอาไฟล์พวกนี้เข้าไปใน .jmd ด้วยโปรแกรมแพ็คของคุณเอง (JmdStudio) โดยใช้ชื่อ/โครงสร้างเดียวกัน

ของใหม่และเลข id — ต้องเพิ่มไอเท็มในฐานข้อมูลเซิฟด้วยเลขพวกนี้ ไม่งั้นจะไม่มีในร้าน/กระเป๋า:
  ป้ายทะเบียน  1101  pg_raycity
  lamp         467   pg_roofsign        (ทรง taxi_round)
  ล้อ          1192  pg_te37_blue       (ทรง rbrc_wolk_te37w)
  ล้อกว้าง     1193  pg_te37_blue_wide  (ทรง rbrc_wolk_te37w_wide)
  ลาย          1001  pg_raycity         (decalinfo)

ลาย (decalinfo): วางตรา PG + RAYCITY ที่ฝากระโปรง, แถบ RAYCITY PG ตามข้างประตู, PG + PG SERVER ท้ายรถ
  ติดบนลายตัวถังรถตาม UV มาตรฐานที่ของแต่งทั่วไปใช้ รถส่วนใหญ่จะลงบนแผงตัวถังพอดี บางคัน UV ต่างกันอาจเยื้องเล็กน้อย

บรรทัดที่ต้องเพิ่มเองใน list.xml (ถ้าของในเกมใหม่กว่า อย่าวางทับ list.xml ให้เพิ่มก่อน </partlist>):
  plate/list.xml      <part id="1101" name="pg_raycity" tex="common_plate_pg_raycity"/>
  lamp/list.xml       <part id='467' name='pg_roofsign' mesh='taxi_round' tex='common_lamp_pg_roofsign'/>
  wheel/list.xml      <part id='1192' name='pg_te37_blue' mesh='rbrc_wolk_te37w' tex='common_wheel_pg_te37_blue'/>
                      <part id='1193' name='pg_te37_blue_wide' mesh='rbrc_wolk_te37w_wide' tex='common_wheel_pg_te37_blue'/>
  decalinfo/list.xml  <part id='1001' name='pg_raycity' tex='decel_pg_raycity'/>
  (list.xml เป็น UTF-16: เปิดด้วย Notepad แล้วบันทึกแบบ Unicode เหมือนเดิม)

หมายเหตุ: ล้อในเกมบางเซิฟอยู่ในไฟล์ wheel.jmd ที่ล็อกไว้ ถ้าวางไฟล์แยกแล้วล้อ PG ไม่ขึ้น
ต้องเอาไฟล์ล้อเข้า wheel.jmd ด้วยโปรแกรมแพ็คของคุณเอง (ผมเปิด/แก้ไฟล์ที่ล็อกให้ไม่ได้)
